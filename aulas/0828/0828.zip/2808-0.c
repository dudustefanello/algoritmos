#include <stdio.h>

int main()
{
	int inteiro = 0;

	if(inteiro == 0)
		printf("OI\n");
	else
		printf("Else ok\n");
		printf("OI\n");
		printf("Tchau\n");
}